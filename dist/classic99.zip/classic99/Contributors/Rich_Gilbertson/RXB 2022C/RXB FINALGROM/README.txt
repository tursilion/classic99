FinalGROM and CLASSIC99 use same binary files.

Note from Tursi: For Classic99, rename RXBC.BIN to RXB8.BIN. (C=8K fixed ROM. 8=74LS378 bank switched ROM)
