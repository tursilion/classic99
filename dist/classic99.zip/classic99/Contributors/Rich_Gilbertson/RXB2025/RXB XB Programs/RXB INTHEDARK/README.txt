
IN THE DARK IS A GAME USING THE SAMS 1 MEG CARD

This game takes up 65 4K pages for a total of 260K
Also 41K of other files.

I did have a version of 960K but would take months to finish game.
(I never even got half way before I died)

Controls are explained in game but a short review:
Space Bar to look around in dark
Enter key using a special token to show a sonar map of screen
Arrow keys to move up, down, left or right
(If you want differnt controls change ARROW keys to S,D,E,X instead)
AID (FCTN 7) Saves game to disk
P key is PAUSE key

Oh and there is a repair bot that fixes traps and wants to kill you.
You can not see it and sound will increase as it get closer, so run!
