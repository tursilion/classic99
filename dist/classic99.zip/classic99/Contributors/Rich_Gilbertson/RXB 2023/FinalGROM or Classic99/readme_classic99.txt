To load these in Classic99, rename RXBC.bin to RXBC_8.bin
