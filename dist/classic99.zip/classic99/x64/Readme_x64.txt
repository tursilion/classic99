This is not production quality. There are a lot of build warnings and I have not investigated any of them. 
In addition, the other DLLs other than cartpack and speech don't even build, and I didn't look at why.

But, some people are running Classic99 under Wine and tell me only the 64-bit version works now, so here you go!
