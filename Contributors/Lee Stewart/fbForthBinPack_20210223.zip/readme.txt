Unpack all files into the same directory.  Run fbForthBinPack in a command 
window from this directory.

fbForthBinPack (by Lee Stewart, 13APR2016) packs the 4 8KiB fbForth 2.0
ROM binaries into inverted or normal (non-inverted) banks in a single 
32KiB binary file that is then replicated as needed to fill any desired
larger-sized binary.

fbForthBinPack should be run in a DOS command window from the directory

    Usage:  fbForthBinPack I|N 32|64|128|256|512

�|� separates choices.
�I� = Inverted bank selection for 74LS379 Guidry/BLACK boards.
�N� = Normal bank selection for 74LS377/378 BLUE/RED boards.
Numeric parameter = Finished size of image file in KiB.

    Example:  fbForthBinPack N 512

The above will produce a 512KiB ROM image file for a BLUE/RED board with
normal bank selection.  The file will be named fbForth200_512N.bin.